# Security Policy

All issues are tracked publicly on GitHub  

Entire code base and indluded dependencies is automatically scanned against known security vulnerabilities  
