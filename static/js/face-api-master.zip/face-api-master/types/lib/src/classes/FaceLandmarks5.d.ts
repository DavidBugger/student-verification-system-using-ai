import { FaceLandmarks } from './FaceLandmarks';
import { Point } from './Point';
export declare class FaceLandmarks5 extends FaceLandmarks {
    protected getRefPointsForAlignment(): Point[];
}
