import { FileSystem } from './types';
export declare function createFileSystem(fs?: any): FileSystem;
