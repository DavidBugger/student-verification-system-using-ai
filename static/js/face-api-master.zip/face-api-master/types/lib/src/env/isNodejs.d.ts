export declare function isNodejs(): boolean;
