import { Environment } from './types';
export declare function createBrowserEnv(): Environment;
