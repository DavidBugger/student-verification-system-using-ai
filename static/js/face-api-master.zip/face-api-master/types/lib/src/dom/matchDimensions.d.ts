import { IDimensions } from '../classes/index';
export declare function matchDimensions(input: IDimensions, reference: IDimensions, useMediaDimensions?: boolean): {
    width: number;
    height: number;
};
