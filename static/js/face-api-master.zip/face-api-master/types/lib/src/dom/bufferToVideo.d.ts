export declare function bufferToVideo(buf: Blob): Promise<HTMLVideoElement>;
