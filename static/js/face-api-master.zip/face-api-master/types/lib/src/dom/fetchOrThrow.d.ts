export declare function fetchOrThrow(url: string, init?: RequestInit): Promise<Response>;
