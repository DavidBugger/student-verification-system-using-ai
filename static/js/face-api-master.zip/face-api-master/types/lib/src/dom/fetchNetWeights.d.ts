export declare function fetchNetWeights(uri: string): Promise<Float32Array>;
