export declare function isMediaLoaded(media: HTMLImageElement | HTMLVideoElement): boolean;
