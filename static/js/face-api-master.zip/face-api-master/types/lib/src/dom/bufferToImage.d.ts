export declare function bufferToImage(buf: Blob): Promise<HTMLImageElement>;
