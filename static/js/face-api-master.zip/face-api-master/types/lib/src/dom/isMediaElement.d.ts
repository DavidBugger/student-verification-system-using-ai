export declare function isMediaElement(input: any): boolean;
