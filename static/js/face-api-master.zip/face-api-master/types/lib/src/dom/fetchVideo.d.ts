export declare function fetchVideo(uri: string): Promise<HTMLVideoElement>;
