export declare function fetchImage(uri: string): Promise<HTMLImageElement>;
