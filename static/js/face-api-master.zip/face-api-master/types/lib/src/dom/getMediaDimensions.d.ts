import { Dimensions, IDimensions } from '../classes/Dimensions';
export declare function getMediaDimensions(input: HTMLImageElement | HTMLCanvasElement | HTMLVideoElement | IDimensions): Dimensions;
