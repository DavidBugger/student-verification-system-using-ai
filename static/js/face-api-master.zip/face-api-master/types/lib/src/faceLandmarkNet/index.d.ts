import { FaceLandmark68Net } from './FaceLandmark68Net';
export * from './FaceLandmark68Net';
export * from './FaceLandmark68TinyNet';
export declare class FaceLandmarkNet extends FaceLandmark68Net {
}
