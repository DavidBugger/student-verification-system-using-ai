import { ParamMapping } from './types';
export declare function disposeUnusedWeightTensors(weightMap: any, paramMappings: ParamMapping[]): void;
