export * from '@tensorflow/tfjs-node';
export { version } from '../../dist/tfjs.version.js';
